## Sobre nosaltres

![img] (diagrama.png)